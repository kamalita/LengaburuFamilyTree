/*
 * Copyright (c) 2020.    @author:KamalitaBiswas
 */

public enum Querries {
    ADD_CHILD,GET_RELATIONSHIP
}


