/*
 * Copyright (c) 2020.    @author:KamalitaBiswas
 */

public class Messages {
    public static String CHILD_ADDED="CHILD_ADDITION_SUCCEEDED";
    public static String CHILD_EXISTS="CHILD_ALREADY_EXISTS";
    public static String CHILD_ADD_FAILED="CHILD_ADDITION_FAILED";
    public static String NONE="NONE";
    public static String PERSON_NOT_FOUND="PERSON_NOT_FOUND";
}
